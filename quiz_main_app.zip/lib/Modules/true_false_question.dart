class QuestionTruFalse {
  String questionName;
  bool questionAnswer;

  QuestionTruFalse(
      {
        required this.questionAnswer,
        required this.questionName
      }
      );

}
