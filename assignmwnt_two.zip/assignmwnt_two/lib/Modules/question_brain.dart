import 'package:assignmwnt_two/Modules/true_false_question.dart';

class Questionbrain {
  int _questionNumber = 0;
  final List<QuestionTruFalse> _banksQuestion = [
    QuestionTruFalse(
        questionAnswer: true, questionName: "Dart is an oop langauage?"),
    QuestionTruFalse(
        questionAnswer: false, questionName: "Dart is not oop langauage?"),
    QuestionTruFalse(
        questionAnswer: true, questionName: "flutter is a framework?"),
    QuestionTruFalse(
        questionAnswer: false,
        questionName:
            'In the animation film “Finding Nemo,” the main protagonist is a pufferfish.'),
    QuestionTruFalse(
        questionAnswer: true,
        questionName: 'Spaghetto is the singular form of the word spaghetti'),
    QuestionTruFalse(
        questionAnswer: false,
        questionName: 'The United Kingdom is almost the same size as France.'),
    QuestionTruFalse(
        questionAnswer: false,
        questionName: 'The capital of Australia is Sydney. '),
  ];

  String getQuestion() {
    return _banksQuestion[_questionNumber].questionName;
  }

  bool getAnswer() {
    return _banksQuestion[_questionNumber].questionAnswer;
  }

  bool isFinished() {
    if (_questionNumber == _banksQuestion.length - 1) {
      return true;
    } else {
      return false;
    }
  }

  void nextQuestion() {
    if (_questionNumber < _banksQuestion.length - 1) {
      _questionNumber++;
    }
  }

  void reset() {
    _questionNumber = 0;
  }
}
